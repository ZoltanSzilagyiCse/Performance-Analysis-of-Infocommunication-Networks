package hu.zoltan.szilagyi.cse.analysisofnetwork;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.text.DecimalFormat;

public class Controller {

    public LineChart<Number, Number> chart;
    public MenuButton menu_button;
    public TextField edit_text_lambda;
    public TextField edit_text_mu;
    public TextField edit_text_x_start;
    public TextField edit_text_x_end;
    public Button button_create;
    public Label text_view_error;
    public TextField edit_text_step;
    public SplitPane split_pane;
    public AnchorPane anchor_pane_right;
    public AnchorPane anchor_pane_left;
    public VBox v_box;
    public CheckBox check_box_square;
    public CheckBox check_box_average;
    public MenuItem menuItemLambda;
    public MenuItem menuItemMu;
    public Text text = new Text("");
    public ScrollPane scrollPanel;

    private XYChart.Series<Number, Number> series = new XYChart.Series<>();
    private XYChart.Series<Number, Number> seriesAverage = new XYChart.Series<>();

    void init() {

        // If the user clicked the generate button, then do the math
        button_create.setOnAction(event -> generateChart());

        // Auto scale the items
        chart.prefWidthProperty().bind(anchor_pane_right.widthProperty());
        chart.prefHeightProperty().bind(split_pane.heightProperty());
        v_box.prefWidthProperty().bind(anchor_pane_left.widthProperty());
        v_box.prefHeightProperty().bind(split_pane.heightProperty());

        scrollPanel.setFitToWidth(true);
        scrollPanel.setContent(text);

        EventHandler<ActionEvent> eventEventHandlerMenu = event -> {
            // Set the menu text
            MenuItem menuItem = (MenuItem) event.getSource();
            menu_button.setText(menuItem.getText());
            edit_text_mu.setDisable(menuItem.getId().equals(menuItemLambda.getId()));
            edit_text_lambda.setDisable(menuItem.getId().equals(menuItemMu.getId()));
            // Auto generate data
            generateChart();
        };

        menuItemMu.setOnAction(eventEventHandlerMenu);
        menuItemLambda.setOnAction(eventEventHandlerMenu);

        EventHandler<ActionEvent> eventHandlerCheckBox = event -> {
            CheckBox checkBox = (CheckBox) event.getSource();
            if (checkBox.isSelected()) {
                if (!chart.getData().contains(checkBox.getId().equals(check_box_square.getId()) ? series : seriesAverage)) {
                    chart.getData().add(checkBox.getId().equals(check_box_square.getId()) ? series : seriesAverage);
                }
            } else {
                chart.getData().remove(checkBox.getId().equals(check_box_square.getId()) ? series : seriesAverage);
            }
        };

        check_box_square.setOnAction(eventHandlerCheckBox);
        check_box_average.setOnAction(eventHandlerCheckBox);

        ChangeListener<String> changeListener = (observable, oldValue, newValue) -> generateChart();

        edit_text_lambda.textProperty().addListener(changeListener);
        edit_text_mu.textProperty().addListener(changeListener);
        edit_text_step.textProperty().addListener(changeListener);
        edit_text_x_end.textProperty().addListener(changeListener);
        edit_text_x_start.textProperty().addListener(changeListener);

        seriesAverage.setName("Válaszolási idő várható értéke");
        series.setName("Válaszolási idő szórásnégyzete");
        System.out.println("Válaszolási idő szórásnégyzete | Válaszolási idő várható értéke");
        text.setText("Válaszolási idő szórásnégyzete | Válaszolási idő várható értéke\n");

        // Simulate the click (this will call the onAction listener)
        check_box_square.fire();
        check_box_average.fire();
        menuItemLambda.fire();
        // Don't need
        button_create.setVisible(false);
    }

    private void generateChart() {
        text.setText("Válaszolási idő szórásnégyzete | Válaszolási idő várható értéke\n");

        // Need to make safer and 'unbreakable'
        if (!check_box_average.isSelected() && !check_box_square.isSelected()) {
            sendError("Nincs megjeleníthető függvény!");
            return;
        }

        double xEnd;
        try {
            xEnd = Double.valueOf(edit_text_x_end.getText());
        } catch (Exception e) {
            sendError("0-9 között adj meg számokat!");
            return;
        }
        double xStart;
        try {
            xStart = Double.valueOf(edit_text_x_start.getText());
        } catch (Exception e) {
            sendError("0-9 között adj meg számokat!");
            return;
        }
        if (xStart == 0) {
            sendError("0 nem lehet!");
            return;
        }
        if (xEnd <= xStart) {
            sendError("A vége nem lehet kisebb a kezdésnél!");
            return;
        }
        double steps;
        try {
            steps = Double.valueOf(edit_text_step.getText());
        } catch (Exception e) {
            sendError("0-9 között adj meg számokat!");
            return;
        }
        if (steps <= 0) {
            sendError("0 vagy annál kisebb nem lehet 2 pont között a távolság!");
            return;
        }
        double lambda;
        try {
            lambda = Double.valueOf(edit_text_lambda.getText());
        } catch (Exception e) {
            sendError("0-9 között adj meg számokat!");
            return;
        }
        double mu;
        try {
            mu = Double.valueOf(edit_text_mu.getText());
        } catch (Exception e) {
            sendError("0-9 között adj meg számokat!");
            return;
        }

        // Remove the current lines from the chart
        series.getData().clear();
        seriesAverage.getData().clear();
        // Set the chart name
        chart.getXAxis().setLabel((edit_text_mu.isDisabled() ?
                /* LAMBDA FIX */ "µ" :
                /* MU FIX */ "λ") +
                " (" + steps + " távolságal)");
        chart.getYAxis().setLabel("Válaszolási idő");
        System.out.println("-------------------------------|-------------------------------");
        // Do the math, then add the result to the line
        // Note: the 'f' incrementing by 'steps', so it will be unique (and greater the previous ones)
        for (double f = xStart; f <= xEnd; f += steps) {

            double ro = edit_text_mu.isDisabled() ?
                    /* LAMBDA FIX */ (lambda / f) :
                    /* MU FIX */ (f / mu);

            double sqr = (edit_text_mu.isDisabled() ?
                    /* LAMBDA FIX */  (ro * (2 - ((ro + 2) * Math.pow(Math.E, -ro)))) / (Math.pow(f, 2) * Math.pow(1 - Math.pow(Math.E, -ro), 2)) :
                    /* MU FIX */ (ro * (2 - ((ro + 2) * Math.pow(Math.E, -ro)))) / (Math.pow(mu, 2) * Math.pow(1 - Math.pow(Math.E, -ro), 2)));

            double avg = (edit_text_mu.isDisable() ?
                    /* LAMBDA FIX */ ro / (f * (1 - Math.pow(Math.E, -ro))) :
                    /* MU FIX*/ ro / (mu * (1 - Math.pow(Math.E, -ro))));

            series.getData().add(new XYChart.Data<>(f, sqr));
            seriesAverage.getData().add(new XYChart.Data<>(f, avg));

            System.out.println("          " +
                    new DecimalFormat("#0.0000000000").format(sqr) +
                    "         |          " +
                    new DecimalFormat("#0.0000000000").format(avg));
            text.setText(text.getText() + "          " +
                    new DecimalFormat("#0.0000000000").format(sqr) +
                    "         |          " +
                    new DecimalFormat("#0.0000000000").format(avg) + "\n");
        }

        // If everything went fine, then remove the error (if it's present)
        sendError("");
    }

    private void sendError(String error) {
        text_view_error.setText(error);
    }
}
