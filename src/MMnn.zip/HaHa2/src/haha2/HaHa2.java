/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package haha2;

//package javafxapplication2;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
//import javafx.scene.Group;
import javafx.scene.Scene;
//import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.CheckBox;
//import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
//import javafx.scene.layout.Border;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
//import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
 
 
public class HaHa2 extends Application {
    
    int lambda;
    double es;
    double ro;
    int minn;
    int maxn;
    boolean pb;
    boolean rb;
    boolean nb;
    boolean kb;
            
    
    long factorial(long i) {
        if(i == 0)
            return 1;
        else 
            return factorial(i - 1) * i;
    }
    
    double normal(double X) {
        double T=1/(1+.2316419*Math.abs(X));
	double D=0.3989423*Math.exp(-X*X/2);
	double Prob=D*T*(0.3193815+T*(-0.3565638+T*(1.781478+T*(-1.821256+T*1.330274))));
	if (X>0) {
		Prob=1-Prob;
	}
	return Prob;
    }
    
    double fi(double x) {
        double Z=x;
        int M=0;
        int SD=1;
        double Prob;
    	if (SD<0) {
            return 1;
	} else if (SD==0) {
            if (Z<M){
		Prob=0;
            } else {
		Prob=1;
            }
	} else {
            Prob=normal((Z-M)/SD);
            //System.out.println("normaling" + Prob);
	}
    
        return Prob;
    }
    
    double b_formula(int n, double ro) {
        double szamlalo = (double)Math.pow(ro, n) / factorial(n);
        double nevezo = 0;
        for(int i = 0; i <= n; i++) {
            nevezo += ((double)Math.pow(ro, i) / factorial((long)i));
        }
        return szamlalo / nevezo;
    }
    
    double b_rekurziv(int n, double ro) {
        if(n == 1)
            return (ro / (1 + ro));
        else {
            double szamlalo = (double)ro * b_rekurziv(n - 1, ro);
            double nevezo = n + szamlalo;
            return szamlalo / nevezo;
        }
    }
    
    double normalis_kozelites(int n, double ro) {
        double szamlalo = fi((n - 1 - ro) / Math.sqrt(ro));
        double nevezo = fi((n - ro) / Math.sqrt(ro));
        return 1 - szamlalo / nevezo;
    }
    
    double korrigalt_normalis_kozelites(int n, double ro) {
        double szamlalo = fi((n - 1 - ro + 0.5) / Math.sqrt(ro));
        double nevezo = fi((n - ro + 0.5) / Math.sqrt(ro));
        return 1 - szamlalo / nevezo;
    }
    
    void rajzol(XYChart.Series s1, XYChart.Series s2, XYChart.Series s3, XYChart.Series s4, double ro, int min_n, int max_n) {
        s1.getData().clear();
        s2.getData().clear();
        s3.getData().clear();
        s4.getData().clear();
        for(int n = min_n; n <= max_n; n++) {
            if(pb && n <= 19)
                s1.getData().add(new XYChart.Data(n, b_formula(n, ro)));
            if(rb)
                s2.getData().add(new XYChart.Data(n, b_rekurziv(n, ro)));
            if(normalis_kozelites(n, ro) >= 0 && nb)
                s3.getData().add(new XYChart.Data(n, normalis_kozelites(n, ro)));
            if(korrigalt_normalis_kozelites(n, ro) >= 0 && kb)
                s4.getData().add(new XYChart.Data(n, korrigalt_normalis_kozelites(n, ro)));
        }
    }
 
    @Override public void start(Stage stage) {
        stage.setTitle("Hálózatok hatékonyságanalízise");
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
         xAxis.setLabel("n");
        final LineChart<Number,Number> lineChart = new LineChart<Number,Number>(xAxis,yAxis);
        lineChart.setTitle("M | M | n | n");
        
        Label lambda_l = new Label("λ");
        Label empty = new Label("");
        Label empty2 = new Label("");
        TextField lambda_in = new TextField();
        Label es_l = new Label("E(S)");
        TextField es_in = new TextField();
        Label n_l = new Label("n");
        
        TextField n_min = new TextField();
        Label p_l = new Label("  ..  ");
        p_l.setMinWidth(20);
        p_l.setMaxWidth(21);
        TextField n_max = new TextField();
        HBox n_b = new HBox(n_min, p_l, n_max);
        
        CheckBox p = new CheckBox();
        CheckBox r = new CheckBox();
        CheckBox n = new CheckBox();
        CheckBox k = new CheckBox();
        CheckBox k2 = new CheckBox();
        HBox prnk = new HBox(p, r, n, k, k2);
        k2.setVisible(false);
        p.setSelected(true);
        r.setSelected(true);
        n.setSelected(true);
        k.setSelected(true);
        prnk.setPadding(new Insets(0,0, 0, 23));
        
        lineChart.setPrefHeight(1000);
        //lineChart.setMaxHeight(850);
        prnk.setMinHeight(25);
        prnk.setMaxHeight(25);
        prnk.setAlignment(Pos.CENTER);
        prnk.setSpacing(93);
        
        VBox Cprnk = new VBox(lineChart, prnk);
        lineChart.autosize();
        
        VBox g = new VBox(lambda_l, lambda_in, empty, es_l, es_in, empty2, n_l, n_b);
        g.setPadding(new Insets(5, 5, 5, 5));
        g.setAlignment(Pos.CENTER);
        g.setMinWidth(110);
        g.setMaxWidth(200);
        
        lambda_in.setText("3");
        es_in.setText("2.0");
        n_min.setText("1");
        n_max.setText("12");
        
        SplitPane splitPane1 = new SplitPane();
        splitPane1.setPrefSize(1280, 700);
        
        //splitPane1.getItems().addAll(lineChart, g);
        splitPane1.getItems().addAll(Cprnk, g);
        Scene scene = new Scene(splitPane1, 1440, 900);
        stage.setScene(scene);
                          
        XYChart.Series series1 = new XYChart.Series();
        series1.setName("Pontos");
        XYChart.Series series2 = new XYChart.Series();
        series2.setName("Rekurziv");
        XYChart.Series series3 = new XYChart.Series();
        series3.setName("Normális");
        XYChart.Series series4 = new XYChart.Series();
        series4.setName("Korrigált normális");
        
        lambda = Integer.parseInt(lambda_in.getText());
        es = Double.parseDouble(es_in.getText());
        minn = Integer.parseInt(n_min.getText());
        maxn = Integer.parseInt(n_max.getText());
        pb = p.isSelected();
        rb = r.isSelected();
        nb = n.isSelected();
        kb = k.isSelected();
        
        rajzol(series1, series2, series3, series4, lambda * es, minn, maxn);
        
        
        lambda_in.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                lambda = Integer.parseInt(newValue);
                rajzol(series1, series2, series3, series4, es * lambda, minn, maxn);
            }
        });
        
        es_in.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                es = Double.parseDouble(newValue);
                rajzol(series1, series2, series3, series4, es * lambda, minn, maxn);
            }
        });
        
        n_min.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                int tmp = Integer.parseInt(newValue);
                
                if(tmp > 0) {
                    minn = tmp;
                    rajzol(series1, series2, series3, series4, es * lambda, minn, maxn);
                }
                else
                    n_min.setText(oldValue); //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        n_max.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                int tmp = Integer.parseInt(newValue);
                
                if(tmp > 0) {
                    maxn = tmp;
                    rajzol(series1, series2, series3, series4, es * lambda, minn, maxn);
                }
                else
                    n_max.setText(oldValue);//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        p.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                pb = newValue;
                rajzol(series1, series2, series3, series4, es * lambda, minn, maxn);
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        r.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                rb = newValue;
                rajzol(series1, series2, series3, series4, es * lambda, minn, maxn);
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        n.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                nb = newValue;
                rajzol(series1, series2, series3, series4, es * lambda, minn, maxn);
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        k.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                kb = newValue;
                rajzol(series1, series2, series3, series4, es * lambda, minn, maxn);
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
        
        lineChart.getData().addAll(series1, series2, series3, series4);
       
        stage.setScene(scene);
        stage.show();
    }
 
 
    public static void main(String[] args) {
        launch(args);
    }
}