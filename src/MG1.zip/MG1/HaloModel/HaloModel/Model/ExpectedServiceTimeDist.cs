﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaloModel.Model
{
    public enum DistributionType { Exp, Erlang, Hipo, Hiper, Constant }

    public class ExpectedServiceTimeDist
    {

        public const double Exponentional = 1d;

        public static double Erlang(int n, double mu = 1d)
        {
            return 1d / n;
        }

        public static double HipoExp(int n, double[] mu)
        {
            if (n != mu.Length)
            {
                throw new ArgumentException("n must be the number of Exponentional distributions!");
            }
            double numerator = 0; // számláló
            double denominator = 0; // nevező
            foreach (var item in mu)
            {
                numerator += Math.Pow((1d / item), 2);
                denominator += 1d / item;
            }
            denominator = Math.Pow(denominator, 2);
            double cs2 = numerator / denominator;
            if (cs2 >= 1 && mu.Length >= 2)
            {
                throw new Exception("The Cs2 must be lower than 1!");
            }
            return cs2;
        }

        public static double HiperExp(double[] p, double[] mu)
        {
            if (p.Length != mu.Length)
            {
                throw new ArgumentException("p and mu must have the same number of elements!");
            }
            double numerator = 0; // számláló
            double denominator = 0; // nevező

            for (int i = 0; i < p.Length; i++)
            {
                numerator += p[i] * Math.Pow(1d / mu[i], 2);
                denominator += p[i] * (1d / mu[i]);
            }
            numerator *= 2;
            denominator = Math.Pow(denominator, 2);
            double cs2 = numerator / denominator - 1;
            if (cs2 < 1 && p.Length >= 2)
            {
                throw new Exception("The Cs2 must be at least 1!");
            }
            return cs2;
        }

    }
}
