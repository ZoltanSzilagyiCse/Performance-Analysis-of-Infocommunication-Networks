﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaloModel.Model
{
    public class ExpectedServiceTime
    {
        public static double Exponentional(double mu)
        {
            return 1 / mu;
        }

        public static double Erlang(int n, double mu)
        {
            return n / mu;
        }

        public static double Hipo(int n, double[] mu)
        {
            double sum = 0;
            for (int i = 0; i < mu.Length; i++)
            {
                sum += 1d / mu[i];
            }
            return sum;
        }

        public static double Hiper(double[] pArr, double[] muArr)
        {
            double sum = 0;
            for (int i = 0; i < muArr.Length; i++)
            {
                sum += pArr[i] * (1d / muArr[i]);
            }
            return sum;
        }

    }
}
