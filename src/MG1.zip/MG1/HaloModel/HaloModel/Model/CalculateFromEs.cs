﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaloModel.Model
{
    class Utils
    {
        public static Random rnd = new Random();
    }

    public class CalculateFromEs
    {
        const Double maxRand = 20;


        public static double Exp(double Es)
        {
            return 1 / Es;
        }

        // n = 2 here
        public static double Erlang(double Es)
        {
            return 2 / Es;
        }

        public static Tuple<double, double> Hipo(double Es)
        {
            double mu1, mu2;
            do
            {
                mu1 = Utils.rnd.Next((int)maxRand) + 5;
                mu2 = 1 / (Es - (1 / mu1) );
            } while (mu1 <= 0 || mu2 <= 0);
            return new Tuple<double, double>(mu1, mu2);
        }

        // mu1, mu2, p1, p2
        public static double[] Hiper(double Es)
        {
            double p1 = Utils.rnd.NextDouble();
            double p2 = 1 - p1;
            double mu1 = Utils.rnd.Next((int)maxRand) + 1;
            double mu2 = 1 / ((Es - (p1 * (1 / mu1))) / p2);
            return new double[] { mu1, mu2, p1, p2 };
        }

    }
}
