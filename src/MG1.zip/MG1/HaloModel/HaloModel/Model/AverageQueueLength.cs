﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaloModel.Model
{
    public class AverageQueueLength
    {

        public static double Ro(double Es, double lamda)
        {
            return Es * lamda;
        }

        public static double QAvgQueueuLength(double ro, double cs2)
        {
            return (Math.Pow(ro, 2) / (1 - ro)) * ((cs2 + 1) / 2);
        }

    }
}
