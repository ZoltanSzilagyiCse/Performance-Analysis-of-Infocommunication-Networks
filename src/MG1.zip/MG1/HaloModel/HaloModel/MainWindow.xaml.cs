﻿using DevExpress.Xpf.Charts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HaloModel.Model;
using System.Text.RegularExpressions;

namespace HaloModel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const int maxValueOnXAxis = 10;

        public MainWindow()
        {
            InitializeComponent();

            XYDiagram2D diagramm = (XYDiagram2D)chartControl1.Diagram;
            diagramm.ActualAxisY.Title = new AxisTitle();
            diagramm.ActualAxisY.Title.Content = "Q átlag";
            diagramm.ActualAxisX.Title = new AxisTitle();
            diagramm.ActualAxisX.Title.Content = "Lamda";

            chartControl1.Diagram.Series[4].Visible = false;
            chartControl1.Diagram.Series[5].Visible = false;
            chartControl1.Diagram.Series[6].Visible = false;
            chartControl1.Diagram.Series[7].Visible = false;

            //checkBoxLambdaFix.RaiseEvent(new RoutedEventArgs(CheckBox.CheckedEvent));
            tab1.IsSelected = true;
            button.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));

            // Create a new chart.

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (tab1.IsSelected)
            {
                if ((expMuVal.Text == "") || (erlangNValue.Text == "") || (erlangMuVal.Text == "") ||
                    (hipoMu1.Text == "") || (hipoMu2.Text == "") || (String.IsNullOrEmpty(hiperMu1.Text)) ||
                    String.IsNullOrEmpty(hiperMu2.Text) || (String.IsNullOrEmpty(hiperP1.Text)))
                {
                    MessageBox.Show("Nincs kitöltve az összes mező!");
                    return;
                }

                double expMu = Double.Parse(expMuVal.Text);
                double erlangMu = Double.Parse(erlangMuVal.Text);
                int erlangN = int.Parse(erlangNValue.Text);
                double hipoM1 = Double.Parse(hipoMu1.Text);
                double hipoM2 = Double.Parse(hipoMu2.Text);
                double hipMu1 = Double.Parse(hiperMu1.Text);
                double hipMu2 = Double.Parse(hiperMu2.Text);
                double hipP1 = Double.Parse(hiperP1.Text);

                LoadChart(expMu, erlangMu, erlangN, hipoM1, hipoM2, hipMu1, hipMu2, hipP1);
            }
            else if (tab2.IsSelected)
            {
                double es = Double.Parse(esTextBox.Text);

                double expMu = CalculateFromEs.Exp(es);
                double erlangMu = CalculateFromEs.Erlang(es);
                int erlangN = 2;

                var hipo = CalculateFromEs.Hipo(es);
                double hipoM1 = hipo.Item1;
                double hipoM2 = hipo.Item2;

                var hiper = CalculateFromEs.Hiper(es);
                double hipMu1 = hiper[0];
                double hipMu2 = hiper[1];
                double hipP1 = hiper[2];

                LoadChart(expMu, erlangMu, erlangN, hipoM1, hipoM2, hipMu1, hipMu2, hipP1);
            }
        }

        public void LoadChart(double expMu, double erlMu, int erlN, double hipoMu1, double hipoMu2,
            double hiperMu1, double hiperMu2, double hiperP1)
        {
            // Exp:
            chartControl1.Diagram.Series[0].Points.Clear();
            for (int i = 0; i < maxValueOnXAxis; i++)
            {
                double expExpectedServiceTime = ExpectedServiceTime.Exponentional(expMu);
                double ro = AverageQueueLength.Ro(expExpectedServiceTime, i);
                if (ro >= 1)
                {
                    break;
                }
                double cs2 = ExpectedServiceTimeDist.Exponentional;
                chartControl1.Diagram.Series[0].Points.Add(new SeriesPoint(i, AverageQueueLength.QAvgQueueuLength(ro, cs2)));
            }

            // Erlang
            chartControl1.Diagram.Series[1].Points.Clear();
            List<double> erlangE = new List<double>();
            for (int i = 0; i < maxValueOnXAxis; i++)
            {
                double expExpectedServiceTime = ExpectedServiceTime.Erlang(erlN, erlMu);
                double ro = AverageQueueLength.Ro(expExpectedServiceTime, i);
                if (ro >= 1)
                {
                    break;
                }
                double cs2 = ExpectedServiceTimeDist.Erlang(erlN, erlMu);
                chartControl1.Diagram.Series[1].Points.Add(new SeriesPoint(i, AverageQueueLength.QAvgQueueuLength(ro, cs2)));
            }

            // Hipo
            chartControl1.Diagram.Series[2].Points.Clear();
            for (int i = 0; i < maxValueOnXAxis; i++)
            {
                double expExpectedServiceTime = ExpectedServiceTime.Hipo(2, new double[] { hipoMu1, hipoMu2 });
                double ro = AverageQueueLength.Ro(expExpectedServiceTime, i);
                if (ro >= 1)
                {
                    break;
                }
                double cs2 = ExpectedServiceTimeDist.HipoExp(2, new double[] { hipoMu1, hipoMu2 });
                chartControl1.Diagram.Series[2].Points.Add(new SeriesPoint(i, AverageQueueLength.QAvgQueueuLength(ro, cs2)));
            }

            // Hiper
            chartControl1.Diagram.Series[3].Points.Clear();
            for (int i = 0; i < maxValueOnXAxis; i++)
            {
                double expExpectedServiceTime = ExpectedServiceTime.Hiper(new double[] { hiperP1, 1 - hiperP1 }, new double[] { hiperMu1, hiperMu2 });
                double ro = AverageQueueLength.Ro(expExpectedServiceTime, i);
                if (ro >= 1)
                {
                    break;
                }
                double cs2 = ExpectedServiceTimeDist.HiperExp(new double[] { hiperP1, 1 - hiperP1 }, new double[] { hiperMu1, hiperMu2 });
                chartControl1.Diagram.Series[3].Points.Add(new SeriesPoint(i, AverageQueueLength.QAvgQueueuLength(ro, cs2)));
            }

        }

        private void PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text);
        }

        private static bool IsTextAllowed(string text)
        {
            Regex regex = new Regex("[^0-9,-]+"); //regex that matches disallowed text
            return !regex.IsMatch(text);
        }

        private void checkBox1_Checked(object sender, RoutedEventArgs e)
        {
            chartControl1.Diagram.Series[0].Visible = true;
        }

        private void checkBox1_Unchecked(object sender, RoutedEventArgs e)
        {
            chartControl1.Diagram.Series[0].Visible = false;
        }

        private void checkBox2_Checked(object sender, RoutedEventArgs e)
        {
            chartControl1.Diagram.Series[1].Visible = true;
        }

        private void checkBox2_Unchecked(object sender, RoutedEventArgs e)
        {
            chartControl1.Diagram.Series[1].Visible = false;
        }

        private void checkBox3_Checked(object sender, RoutedEventArgs e)
        {
            chartControl1.Diagram.Series[2].Visible = true;
        }

        private void checkBox3_Unchecked(object sender, RoutedEventArgs e)
        {
            chartControl1.Diagram.Series[2].Visible = false;
        }

        private void checkBox4_Checked(object sender, RoutedEventArgs e)
        {
            chartControl1.Diagram.Series[3].Visible = true;
        }

        private void checkBox4_Unchecked(object sender, RoutedEventArgs e)
        {
            chartControl1.Diagram.Series[3].Visible = false;
        }

    }
}
