package sample;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

import static java.lang.Math.round;

public class Controller {
    public LineChart<Number, Number> chart;
    public MenuButton menu_button;

    //Ezek lesznek a mezők változói
    public TextField edit_text_lambda;
    public TextField edit_text_mu;
    public TextField edit_text_K;
    public TextField edit_text_x_start;
    public TextField edit_text_x_end;
    public TextField edit_text_step;
    public TextField edit_text_blokk;

    //Ehhez én nem nyúltam, mert speckó változók
    public Button button_create;
    public Label text_view_error;
    public SplitPane split_pane;
    public AnchorPane anchor_pane_right;
    public AnchorPane anchor_pane_left;
    public VBox v_box;

    //Azért van csak 2, mert nem tudtam többet kezelni a megjelenítésnél (pipálgatások miatt)
    public CheckBox check_box_N;
    public CheckBox check_box_N_2;

    //Ezek pedig a leegördülő listából az opciók
    public MenuItem menuItemLambda;
    public MenuItem menuItemMu;
    public MenuItem menuItemK;

    //Ezek lesznek a függvény görbéi
    private XYChart.Series<Number, Number> series_N = new XYChart.Series<>();
    private XYChart.Series<Number, Number> series_N_2 = new XYChart.Series<>();
    private XYChart.Series<Number, Number> series_Q = new XYChart.Series<>();
    private XYChart.Series<Number, Number> series_Q_2 = new XYChart.Series<>();
    private XYChart.Series<Number, Number> series_T = new XYChart.Series<>();
    private XYChart.Series<Number, Number> series_T_2 = new XYChart.Series<>();
    private XYChart.Series<Number, Number> series_B = new XYChart.Series<>();

    //Ehhez megint csak nem nyúltam
    void init() {
        button_create.setOnAction(event -> generateChart());
        chart.prefWidthProperty().bind(anchor_pane_right.widthProperty());
        chart.prefHeightProperty().bind(split_pane.heightProperty());
        v_box.prefWidthProperty().bind(anchor_pane_left.widthProperty());
        v_box.prefHeightProperty().bind(split_pane.heightProperty());

        EventHandler<ActionEvent> eventEventHandlerMenu = event -> {
            MenuItem menuItem = (MenuItem) event.getSource();
            menu_button.setText(menuItem.getText());
            edit_text_mu.setDisable(menuItem.getId().equals(menuItemMu.getId()));
            edit_text_lambda.setDisable(menuItem.getId().equals(menuItemLambda.getId()));
            edit_text_K.setDisable(menuItem.getId().equals(menuItemK.getId()));
            generateChart();
        };

//Ha lesz új elem a legördülő listában, akkor itt vegyetek fel egy új parancsot hozzá
        menuItemMu.setOnAction(eventEventHandlerMenu);
        menuItemLambda.setOnAction(eventEventHandlerMenu);
        menuItemK.setOnAction(eventEventHandlerMenu);

//És itt jön ki, hogy miért csak 2 checkboxot csináltam, mert nem tudtam megoldani, hogy a görbéket külön-külön mutassa vagy rejtse el, így maradt az hogy csoportban jelennek meg
        EventHandler<ActionEvent> eventHandlerCheckBox = event -> {
            CheckBox checkBox = (CheckBox) event.getSource();
            if (checkBox.isSelected()) {
                if (!chart.getData().contains(checkBox.getId().equals(check_box_N.getId()) ? series_N : series_N_2)) {
                    chart.getData().add(checkBox.getId().equals(check_box_N.getId()) ? series_N : series_N_2);
                    chart.getData().add(checkBox.getId().equals(check_box_N.getId()) ? series_Q : series_Q_2);
                    chart.getData().add(checkBox.getId().equals(check_box_N.getId()) ? series_T : series_T_2);
                    chart.getData().add(checkBox.getId().equals(check_box_N.getId()) ? series_T : series_B);
                }
            }
            else{
                chart.getData().remove(checkBox.getId().equals(check_box_N.getId()) ? series_N : series_N_2);
                chart.getData().remove(checkBox.getId().equals(check_box_N.getId()) ? series_Q : series_Q_2);
                chart.getData().remove(checkBox.getId().equals(check_box_N.getId()) ? series_T : series_T_2);
                chart.getData().remove(checkBox.getId().equals(check_box_N.getId()) ? series_T : series_B);
            }
        };
//Itt ugyanaz van, hogy ha csináltok valami új mezőt, akkor ide vegyétek fel!!!
        check_box_N.setOnAction(eventHandlerCheckBox);
        check_box_N_2.setOnAction(eventHandlerCheckBox);

        ChangeListener<String> changeListener = (observable, oldValue, newValue) -> generateChart();
        edit_text_lambda.textProperty().addListener(changeListener);
        edit_text_mu.textProperty().addListener(changeListener);
        edit_text_K.textProperty().addListener(changeListener);
        edit_text_step.textProperty().addListener(changeListener);
        edit_text_blokk.textProperty().addListener(changeListener);
        edit_text_x_end.textProperty().addListener(changeListener);
        edit_text_x_start.textProperty().addListener(changeListener);

        series_N.setName("M|M|1 Igények átlagos száma");
        series_N_2.setName("M|M|1|K Igények átlagos száma");
        series_Q.setName("M|M|1 Sorhossz átlagos száma");
        series_Q_2.setName("M|M|1|K Sorhossz átlagos száma");
        series_T.setName("M|M|1 Tartózkodási idő átlagos ideje");
        series_T_2.setName("M|M|1|K Tartózkodási idő átlagos ideje");
        series_B.setName("M|M|1|K Blokkolási valószínűség");

        check_box_N.fire();
        check_box_N_2.fire();
        menuItemLambda.fire();
        menuItemMu.fire();
        menuItemK.fire();

        button_create.setVisible(false);
    }

    //Itt kezdődik a hibakiírás és játék a számokkal, mégpedig:
    private void generateChart() {
        if (!check_box_N.isSelected() && !check_box_N_2.isSelected()) {
            sendError("Nincs megjeleníthető függvény!");
            return;
        }

        double xEnd;
        try {
            xEnd = Double.valueOf(edit_text_x_end.getText());
        } catch (Exception e) {
            sendError("0-9-ig adjon meg számokat!");
            return;
        }
        double xStart;
        try {
            xStart = Double.valueOf(edit_text_x_start.getText());
        } catch (Exception e) {
            sendError("0-9-ig adjon meg számokat!");
            return;
        }
        if (xStart == 0) {
            sendError("0 nem lehet!");
            return;
        }
        if (xEnd <= xStart) {
            sendError("A vége nem lehet kisebb a kezdésnél!");
            return;
        }
        double steps;
        try {
            steps = Double.valueOf(edit_text_step.getText());
        } catch (Exception e) {
            sendError("0-9 között adj meg számokat!");
            return;
        }
        if (steps <= 0) {
            sendError("0 vagy annál kisebb nem lehet 2 pont között a távolság!");
            return;
        }

        double blokk;
        try {
            blokk = Double.valueOf(edit_text_blokk.getText());
        } catch (Exception e) {
            sendError("0 és 1 között adj meg számokat!");
            return;
        }

//Látod itt rendelődik a mező értéke a változóhoz
        double lambda;
        try {
            lambda = Double.valueOf(edit_text_lambda.getText());
        } catch (Exception e) {
            sendError("Adjon meg számokat!");
            return;
        }
        double mu;
        try {
            mu = Double.valueOf(edit_text_mu.getText());
        } catch (Exception e) {
            sendError("Adjon meg számokat!");
            return;
        }

        double K;
        try {
            K = Integer.valueOf(edit_text_K.getText());
        } catch (Exception e) {
            sendError("Adjon meg egy természetes számot!");
            return;
        }

//Görbék üresek lesznek
        series_N.getData().clear();
        series_N_2.getData().clear();
        series_Q.getData().clear();
        series_Q_2.getData().clear();
        series_T.getData().clear();
        series_T_2.getData().clear();
        series_B.getData().clear();

        if(edit_text_mu.isDisable() ){
            chart.getXAxis().setLabel("µ" + " (" + steps + " távolsággal)");
        }
        if(edit_text_lambda.isDisable()){
            chart.getXAxis().setLabel("λ" + " (" + steps + " távolsággal)");
        }
        if(edit_text_K.isDisable()){
            chart.getXAxis().setLabel("K" + " (" + steps + " távolsággal)");
        }
        chart.getYAxis().setLabel("Érték");

//Számolás
        for (double f = xStart; f <= xEnd; f += steps) {
            double ro=0;
            if(edit_text_K.isDisable())
                ro=lambda/mu;
            if(edit_text_mu.isDisable())
                ro=lambda/f;
            if(edit_text_lambda.isDisable())
                ro=f/mu;

            if(ro>=1){
                continue;
            }

            double N;
            N = ro / (1-ro);

//És ez az a parancs, amivel az értéket hozzárendeljük az fgv. vízszintestengelybeli értékéhez
            series_N.getData().add(new XYChart.Data<>(f, N));

            N=0;
            double pk;
            if(edit_text_K.isDisable()){
                for(int k=1; k<=f; k++){
                    pk =( (Math.pow(ro, k)) * (1-ro)) / (1 - (Math.pow(ro, f+1)));
                    N+=k*pk;
                }
            }
            else{
                for(int k=1; k<=K; k++){
                    pk =( (Math.pow(ro, k)) * (1-ro)) / (1 - (Math.pow(ro, K+1)));
                    N+=k*pk;
                }
            }
            series_N_2.getData().add(new XYChart.Data<>(f, N));

            double Q;
            Q = (Math.pow(ro, 2)) / (1 - ro);
            series_Q.getData().add(new XYChart.Data<>(f, Q));

            double p0=0;
            if(edit_text_K.isDisable()){
                p0 = (1-ro) / (1 - (Math.pow(ro, f+1)));
            }
            else{
                p0 = (1-ro) / (1 - (Math.pow(ro, K+1)));
            }
            Q = N - (1-p0);
            series_Q_2.getData().add(new XYChart.Data<>(f, Q));

            double T=0;
            if(edit_text_mu.isDisable()){
                T = 1 / (f * (1-ro));
            }
            else{
                T = 1 / (mu * (1-ro));
            }
            series_T.getData().add(new XYChart.Data<>(f, T));

            double pK;
            if(edit_text_K.isDisable()){
                pK = (Math.pow(ro, f) * (1-ro)) / ( 1 - Math.pow(ro, f+1));
            }
            else{
                pK = (Math.pow(ro, K) * (1-ro)) / ( 1 - Math.pow(ro, K+1));
            }

            if(edit_text_lambda.isDisable())
                T = N / (f * (1-pK));
            else
                T = N / (lambda * (1-pK));
            series_T_2.getData().add(new XYChart.Data<>(f, T));

            double b;
            if(edit_text_K.isDisable()){
                b = blokkol((int) round(f), ro);
            }
            else{
                b = blokkol( (int) K, ro);
            }
            if(b < blokk)
                series_B.getData().add(new XYChart.Data<>(f, b));
        }

        if(lambda/mu >= 1)
            sendError("Ró nagyobb vagy egyenlő, mint 1!");
        else
            sendError("");
    }

    private void sendError(String error) {
        text_view_error.setText(error);
    }

    //Ez pedig nekem volt egy rekurzív cuccos
    private double blokkol(int K, double ro){
        if(K==1){
            return ro / (1 + ro);
        }
        return (ro * blokkol(K-1, ro)) / ( 1 + ro * blokkol(K-1,ro));
    }
}
